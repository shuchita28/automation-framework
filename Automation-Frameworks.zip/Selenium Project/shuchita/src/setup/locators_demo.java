package setup;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;

public class locators_demo {
	
	public static void main (String args[]) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		String baseUrl = "https://www.facebook.com";
		ArrayList<String> locator_names =new ArrayList<String>();
		String name = "";
		
		driver.get(baseUrl);
		
		/*Using locators (also called locator strategy) to find GUI elements:
		 * getTagName() returns the HTML tag which the element has on GUI page
		 * linkText and partialLinkText work on hyperlink elements only 
		 * Go to HTML page, inspect element and obtain HTMLtag/class name/id/xpath/selector 
		 * 
		 * Using FindElement command
		 * This command takes By object as parameter and returns an object of WebElement
		 * We are using .getTagName () to translate the object to string
		 */
		
		//1. By.className() Selenium does not accept className with blankspaces in between. It gives "Compound classes not accepted" error.
			
		
			/*driver.findElement(By.className("inputtext")).sendKeys("Testing");
			driver.findElement(By.className("inputtext")).sendKeys("Testing");*/
		
		
			name = driver.findElement(By.className("inputtext")).getTagName();
			locator_names.add(name);
		
		//2. By.id()
			name = driver.findElement(By.id("email")).getTagName();
			locator_names.add(name);
			
		//3. By.cssSelector() syntax: tagName[attribute='value'] OR tagName#id OR tagName.classname 
			name = driver.findElement(By.cssSelector("#email")).getTagName();
			locator_names.add(name);
			
		//4. By.xpath() syntax: //tagName[@attribute='value'] if tagName = * means accept any tagName with that attribute value
			name = driver.findElement(By.xpath("//*[@id=\"email\"]")).getTagName();
			locator_names.add(name);
			driver.findElement(By.xpath("//input[contains(@name,'first')]")).sendKeys("Hello");
			
			/*xpath() is of two types (on the basis of way we traverse the path of locator): relative and absolute-
			 * Relative xpath: We jump directly to the object/node we require WITHOUT depending on the parent node. Preferred as it goes directly
			 * to the object node and not dependent on any parent nodes
			 * Example: //input[@id='xyz']
			 * 
			 * Absolute xpath: We find the object/node using the parent nodes (traversing via parent/grandparent nodes). Not preferred because 
			 * it depends on parent nodes and that may sometimes be incorrect/break
			 * Example: //grandparentNode/parentNode/childNode
			 */
			//driver.navigate().back();
		
		//5. By.name()
			name = driver.findElement(By.name("email")).getTagName();
			locator_names.add(name);
		
		//6. By.tagName()
			name = driver.findElement(By.tagName("input")).getTagName();
			locator_names.add(name);
			
		//7. By.linkText()
			name = driver.findElement(By.linkText("Forgotten account?")).getTagName();
			locator_names.add(name);
			
		//8. By.partialInkText()
			name = driver.findElement(By.partialLinkText("Terms")).getTagName();
			locator_names.add(name);
		
			System.out.println("\n This is FindElement"+locator_names);
		
		
		/*Using FindElements:
		 * This command takes By object as parameter and returns a list of WebElement objects which all correspond to 
		 * same locator strategy as defined
		 */
		List<WebElement> locator_names_2 = driver.findElements(By.id("email"));
		System.out.println("\n This is FindElements"+locator_names_2);
		
		
		//driver.close();
		System.exit(0);
		
	}

}
