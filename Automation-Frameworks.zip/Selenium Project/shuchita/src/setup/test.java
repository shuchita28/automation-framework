package setup;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
//imports the class 'WebDriver' which instantiates a new browser loaded with specific driver
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
//imports the class 'ChromeDriver' which is needed to instantiate the driver onto the browser
public class test {

    public static void main(String[] args) {
        // declaration and instantiation of objects/variables
    	//Declaring which browser driver we will use and where it is located.
    	/*ChromeDriver class of WebDriver interface invoked .setProperty function which maps key = webdriver.chrome.driver 
    	  to value = location of chromedriver.exe*/
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
    	
        String baseUrl = "http://demo.guru99.com/test/newtours/";
        String expectedTitle = "Welcome: Mercury Tours";
        String actualTitle = "";

        // launch Chrome and direct it to the Base URL
        driver.get(baseUrl);
        System.out.println("The expected title is: "+expectedTitle);
        // get the actual value of the title
        actualTitle = driver.getTitle();
        System.out.println("The actual title of "+baseUrl+" is: "+actualTitle);
        /*
         * compare the actual title of the page with the expected one and print
         * the result as "Passed" or "Failed"
         */
        driver.findElement(By.xpath("//*[@id='site-name']/a")).click();
       
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        
        //Assert is used for validation of the response
        Assert.assertTrue(driver.findElement(By.xpath("//*[@id='site-name']/a")).isDisplayed());
        System.out.println("*****TEST HAS PASSED*****");
        //Assert.assertTrue(driver.findElement(By.xpath("//*[@id='site-name']/a")).isSelected());

        if (actualTitle.contentEquals(expectedTitle)){
            System.out.println("The titles match. Hence, Test Passed!");
        } else {
            System.out.println("The titles do not match. Sorry, Test Failed");
        }
        
        //Using Assert validation: 
        Assert.assertEquals(driver.getTitle(), expectedTitle);
       
        String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,"t");
        driver.findElement(By.tagName("body")).sendKeys(selectLinkOpeninNewTab);        
        //close Chrome browser
        //driver.close();
       
        //Exit Java program
        //System.exit(0);
    }

}