package setup;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import com.google.common.io.Files;

public class Lecture14_Screenshot {

	public static void main (String args[]) throws IOException {
		
		//How to declare capabilities for your chrome browser to accpt/decline SSL certificates and Insecure URLs
		DesiredCapabilities ch=DesiredCapabilities.chrome();
		//ch.acceptInsecureCerts();
		ch.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		ch.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

		//Merge desired capabilities to your local browser
		ChromeOptions c= new ChromeOptions();
		c.merge(ch);
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver(c);
		
		driver.get("https://www.rahulshettyacademy.com/seleniumPractise/#/offers");
		
		List<WebElement> fruits = driver.findElements(By.xpath("//*[@id=\"sortableTable\"]/tbody/tr/td[2]"));
		ArrayList<String> fruits_org = new ArrayList<String>();
		
		for(int i=0;i<fruits.size();i++) {
			fruits_org.add(fruits.get(i).getText());
			System.out.print(fruits_org.get(i)+ "\t");
		}
		System.out.println();
		
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//List<WebElement> fruits_sorted = fruits_org.sort();
		driver.findElement(By.xpath("//*[@id=\"sortableTable\"]/thead/tr/th[2]")).click();
		
		List<WebElement> fruits_sorted = driver.findElements(By.xpath("//*[@id=\"sortableTable\"]/tbody/tr/td[2]"));
		ArrayList<String> fruits_sort = new ArrayList<String>();
		
		for(int i=0;i<fruits_sorted.size();i++) {
			fruits_sort.add(fruits_sorted.get(i).getText());
			System.out.print(fruits_sort.get(i)+ "\t");
		}
		System.out.println();
		Collections.sort(fruits_org, Collections.reverseOrder());
		//System.out.println(fruits_org);
		Assert.assertTrue(fruits_org.equals(fruits_sort), "Fruits/Veg are not in sync.");
		
		 	
		driver.close();
		/*File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("C:\\Users\\Toshiba\\Desktop\\Selenium_Notes\\Screenshot_GreenKart.jpeg"));*/
		
		
		
	}
}
