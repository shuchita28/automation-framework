package setup;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class findElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://demo.guru99.com/test/ajax.html");
		

		List<WebElement> radio_text = driver.findElements(By.name("name"));
		
		/*getText() returns the innerText of the WebElment 
		  getAttribute(String) returns the value of the attribute passed to it
		 */
		for (int i=0;i<radio_text.size();i++) {
			System.out.print("\t Text:"+radio_text.get(i).getAttribute("value"));
		}
		
		driver.close();
		System.exit(0);
	}

}
