package setup;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.concurrent.TimeUnit;
public class Synchronisation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		/*2 types of waits:
		 * 1. Implicit wait:
		 * - Wait time standardized for entire program
		 * - Easier to implement than explicit wait
		 */
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		/*driver.get() : Doesn't maintain the browser History and cookies
		  				 we can't use forward and backward button as page gets refreshed
		  driver.navigate() : Maintains the browser history and cookies
		  				 we can use forward and backward button to navigate between the pages.
		*/
		driver.get("https://www.google.com");
		
		//instantiated a WebElement object which can be referred each time particular element is accessed. 
		WebElement element = driver.findElement(By.cssSelector("#tsf > div:nth-child(2) > div.A8SBwf > div.RNNXgb > div > div.a4bIc > input"));
		//System.out.println(element.getText());
		element.click();
		element.sendKeys("Selenium");
		element.sendKeys(Keys.RETURN);
		
		/*2. Explicit wait:
		 * - WebDriverWait instance used to define what will wait and for how long
		 * - Expected Conditions to be applied on instances where wait event is required
		 */
		WebDriverWait wait_var = new WebDriverWait(driver,10);
		wait_var.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("About Selenium")));
		
		
		/*Switching between frames on a multi-frame page
		 * 1. Switch to desired frame using switchTo().frame() 
		 * 2. Enter the frame 'name' in frame() function
		 * 3. Get the element to be accessed using findElement()
		 */
		driver.navigate().back();
		
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		
		driver.navigate().to("http://demo.guru99.com/selenium/deprecated.html");
		driver.switchTo().frame("classFrame");
		driver.findElement(By.linkText("Deprecated")).click();
		//Switching to alert pop-ups: switchTo().alert() , switchTo().alert().accept()
		
		
		driver.close();
		
		/*driver.get("http://www.itgeared.com/demo/1506-ajax-loading.html");
		driver.findElement(By.linkText("Click to load get data via Ajax!")).click();
		WebDriverWait wait = new WebDriverWait (driver,5);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("results")));
		System.out.println(driver.findElement(By.id("results")).getText());*/
		
		/*Fluent wait: 
		 * fluent wait repeatedly searches for the webelement at regular intervals of time until webelement is found or timeout happens.
		 */
		System.exit(0);
		
	}

}
