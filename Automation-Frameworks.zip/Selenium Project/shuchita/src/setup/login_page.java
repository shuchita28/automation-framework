package setup;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;

public class login_page {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		
		/*Disabling Chrome notifications in browser:
		Map<String, Object> preference = new HashMap<String, Object>();
		preference.put("profile.default_content_setting_values.notifications", 2);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("preference", preference);
		
		WebDriver d = new ChromeDriver(options);*/
		
		//Create prefs map to store all preferences 
		Map<String, Object> prefs = new HashMap<String, Object>();

		//Put this into prefs map to switch off browser notification
		prefs.put("profile.default_content_setting_values.notifications", 2);

		//Create chrome options to set this prefs
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);

		//Now initialize chrome driver with chrome options which will switch off this browser notification on the chrome browser
		WebDriver d = new ChromeDriver(options);

		//Now do your further steps
		WebDriverWait wait_var = new WebDriverWait(d,5);
		
		d.get("https://www.facebook.com");
		d.manage().window().maximize();
		
		d.findElement(By.name("firstname")).sendKeys("Shiro");
		d.findElement(By.name("lastname")).sendKeys("Varma");
		d.findElement(By.cssSelector("#u_0_r")).sendKeys("abc@gmail.com");
		wait_var.until(ExpectedConditions.visibilityOfElementLocated(By.name("reg_email_confirmation__")));
		d.findElement(By.name("reg_email_confirmation__")).sendKeys("abc@gmail.com");
		d.findElement(By.xpath("//*[@id=\'u_0_w\']")).sendKeys("Test@1234");
		
		/*For selecting values from drop down: (https://www.guru99.com/select-option-dropdown-selenium-webdriver.html)
		This is Static drop down. Select class object will find the element and pass all methods of the Select class to that element object. 
		That is why we pass the driver object as argument while creating Select object*/
		
		Select day = new Select(d.findElement(By.name("birthday_day")));
		day.selectByVisibleText("28");
		Select month = new Select(d.findElement(By.name("birthday_month")));
		month.selectByVisibleText("May");
		Select year = new Select(d.findElement(By.name("birthday_year")));
		year.selectByVisibleText("1996");
		
		d.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		d.findElement(By.id("u_0_7")).click();
		d.findElement(By.id("u_0_13")).click();
		
		
		
		
				
		//wait_var.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Send Email Again")));
		
		/*WebDriver d2 = new ChromeDriver(options);
		d2.get("https://www.gmail.com");*/
		
		
		
		
		//d.close();
		
		System.out.println("First page loaded");
		
		

		
	}

}
