package setup;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
//import org.testng.Assert;

public class CartCheckout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		WebDriver driver = new ChromeDriver(options);
		
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		List<WebElement> products = driver.findElements(By.cssSelector("h4.product-name"));
		String veggies[] = {"Cucumber", "Brocolli", "Potato"};
		int k=0;
		
		for (int i=0;i<products.size();i++)
		{
			List<String> veggiesList = Arrays.asList(veggies);
			String product_name = products.get(i).getText().split("-")[0].trim();
			if(veggiesList.contains(product_name))
			{
				k++;
				//System.out.println(product_name);
				//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				//driver.findElements(By.xpath("//button[text()='ADD TO CART']")).get(i).click();
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
				//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				if(k>=veggies.length)
					break;
			}
			
		}
		System.out.println(k);
	
		//driver.findElement(By.id("twotabsearchtextbox")).sendKeys("handwash");
		
		
	}

}
