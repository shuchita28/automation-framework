package setup;

import org.testng.annotations.Test;

public class intro {

	@Test
	public void demo() {
		System.out.println("Hi TestNG!" );
	}
}
