package setup;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
//import org.testng.Assert;




public class Assignment2 {
	public static void main(String[] args) throws InterruptedException {

		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toshiba\\chromedriver_win32\\chromedriver.exe");
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		WebDriver driver = new ChromeDriver(options);
		//WebDriver driver =new ChromeDriver();

		driver.get("https://rahulshettyacademy.com/AutomationPractice/"); 
		/*Select adult = new Select(driver.findElement(By.name("adults")));
		adult.selectByVisibleText("7");
		Select children = new Select(driver.findElement(By.name("childs")));
		children.selectByVisibleText("2");

		driver.findElement(By.xpath("//*[@id=\'ORtrip\']/section[2]/div[1]/dl/dd/div/a/i")).click();
		driver.findElement(By.xpath("//*[@id=\'ui-datepicker-div\']/div[1]/table/tbody/tr[5]/td[2]/a")).click();
		driver.findElement(By.xpath("//*[@id=\'MoreOptionsLink\']")).click();
		driver.findElement(By.id("AirlineAutocomplete")).sendKeys("Indigo");
		driver.findElement(By.id("SearchBtn")).click();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		System.out.println(driver.findElement(By.id("homeErrorMessage")).getText());*/
		
		driver.findElement(By.xpath("//input[@id='checkBoxOption2']")).click();
		
		String value = driver.findElement(By.xpath("//*[@id=\"checkbox-example\"]/fieldset/label[2]")).getText();
		System.out.println(value);
		
		Select dropdown = new Select(driver.findElement(By.id("dropdown-class-example")));
		dropdown.selectByVisibleText(value);
		
		driver.findElement(By.xpath("//input[@id='name']")).sendKeys(value);
		driver.findElement(By.xpath("//input[@id='alertbtn']")).click();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.switchTo().alert();
		
		String alertText = driver.switchTo().alert().getText();
		
		Assert.assertTrue(alertText.contains(value));
		
		//driver.close();
		//System.exit(0);

	}

}

