package frameworks.Mavenjava;

import org.testng.annotations.Test;

public class AppiumTest {

	@Test
	public void AndroidApp() {
		System.out.println("Android apps ");
	}
	
	@Test
	public void IOSApp() {
		System.out.println("IOS apps");
	}
}
