package frameworks.Mavenjava;

import org.testng.annotations.Test;

public class RestAPITest {

	@Test
	public void postJira() {
		System.out.println("Post Jira");
	}
	
	@Test
	public void deleteTwitter() {
		System.out.println("Delete Twitter");
	}
}
