package frameworks.Mavenjava;

import org.testng.annotations.Test;

public class SeleniumTest {

	@Test
	public void BrowseAutomation() {
		System.out.println("Browser Automation");
	}
	
	@Test
	public void ElementsUI() {
		System.out.println("Elements UI Testing");
	}
}
