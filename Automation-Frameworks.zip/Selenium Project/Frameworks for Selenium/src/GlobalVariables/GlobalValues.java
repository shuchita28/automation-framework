package GlobalVariables;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class GlobalValues {

	public static void main(String args[]) throws IOException {
	
	Properties p = new Properties();
	FileInputStream fi = new FileInputStream("C:\\Users\\Toshiba\\eclipse-workspace\\Frameworks for Selenium\\src\\Sample\\data.properties");
	p.load(fi);
	
	System.out.println(p.getProperty("browser"));
	
	p.setProperty("browser", "Firefox");
	
	System.out.println(p.getProperty("browser"));
	
	FileOutputStream fo =new FileOutputStream("C:\\Users\\Toshiba\\eclipse-workspace\\Frameworks for Selenium\\src\\Sample\\data.properties");
	p.store(fo, null);
	
	}
}
