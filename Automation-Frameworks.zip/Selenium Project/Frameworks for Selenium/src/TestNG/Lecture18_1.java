package TestNG;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Lecture18_1 {
  @Test
  public void demo() {
	  System.out.println("Hi!");
  }
  
 // This will execute at the last of the Test folder in which this class is included in testng.xml
  @AfterTest
  public void Last() {
	  System.out.println("I am being executed last in this test!");
	  System.out.println();
  }
  
  //This will execute at the last of the Test suite in which this class is included in testng.xml
  @AfterSuite
  public void LastOfAll() {
	  System.out.println("The LAST test in this suite. See you again !");
  }
  
  @Test
  public void sample() {
	  System.out.println("Goodbye for now!");
  }
	  
  @Test(groups= {"Shuchita"})
  public void groups_samp1() {
	  System.out.println("Hi! I'm a part of a group called Shuchita.");
  }
}
