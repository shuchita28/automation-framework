package TestNG;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Lecture18_4 {
	
  
  
  @Test(groups= {"Shuchita"})
  public void group_samp3() {
	  System.out.println("Btw! I am a part of Shuchita, as well!");
  }
  
  @Parameters({"URL"})
  @Test
  public void Testing_URL(String urlname) {
  System.out.println("Here is the URL you asked for in class 4!");
  System.out.println(urlname);
  }
  
  
}
