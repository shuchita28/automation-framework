package TestNG;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Lecture18_2 {
  @Test
  public void Demo2() {
	  System.out.println("Hi again!");
  }
  
  @Test(groups= {"Shuchita"})
  public void group_samp2() {
	  System.out.println("Hi! I am also a part of Shuchita.");
  }
  
  @Test
  public void Demo3() {
	  System.out.println("Hi! Only I am included from class 2");
  	}
  
  @BeforeTest
  public void  First() {
	  System.out.println();
	  System.out.println("I am being executed first!");
  }
}
