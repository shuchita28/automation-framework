package TestNG;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Lecture18_3 {
  
	@Parameters({"URL","NewURL/newvalue"})
	
	@Test
  public void WebLogin(String urlname, String key) {
	  System.out.println("Web login");
	  System.out.println("The url you asked for in class 3: "+urlname);
	  System.out.println("The key is: "+key);
  }
  
  @Test
  public void MobileLogin()
  {
	  System.out.println("Mobile login");
  }
  
  @Test
  public void APILogin()
  {
	  System.out.println("REST API Login");
  }
}
